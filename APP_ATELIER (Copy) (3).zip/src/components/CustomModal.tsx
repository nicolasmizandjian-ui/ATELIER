import React, { useEffect } from 'react';
import { X } from 'lucide-react';
import { Button } from './ui/button';

interface CustomModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  description?: string;
  children: React.ReactNode;
}

export function CustomModal({ isOpen, onClose, title, description, children }: CustomModalProps) {
  // Empêcher le scroll du body quand la modal est ouverte
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  // Fermer avec Escape
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };

    if (isOpen) {
      document.addEventListener('keydown', handleEscape);
    }

    return () => {
      document.removeEventListener('keydown', handleEscape);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(0, 0, 0, 0.8)',
        zIndex: 999999,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '20px'
      }}
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          onClose();
        }
      }}
    >
      <div
        style={{
          backgroundColor: '#1f2937', // gray-800
          borderRadius: '12px',
          border: '1px solid #374151', // gray-700
          width: '60vw',
          maxWidth: '60vw',
          height: '70vh',
          maxHeight: '70vh',
          display: 'flex',
          flexDirection: 'column',
          overflow: 'hidden',
          boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)'
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div
          style={{
            padding: '24px',
            borderBottom: '1px solid #374151', // gray-700
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'flex-start'
          }}
        >
          <div>
            <h2 style={{ 
              fontSize: '24px', 
              fontWeight: 'bold', 
              color: 'white',
              margin: 0,
              marginBottom: description ? '8px' : 0
            }}>
              {title}
            </h2>
            {description && (
              <p style={{ 
                color: '#9ca3af', // gray-400
                margin: 0,
                fontSize: '16px'
              }}>
                {description}
              </p>
            )}
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={onClose}
            style={{
              backgroundColor: 'transparent',
              border: '1px solid #374151',
              color: '#9ca3af',
              padding: '8px'
            }}
          >
            <X className="w-4 h-4" />
          </Button>
        </div>

        {/* Content */}
        <div
          style={{
            flex: 1,
            overflow: 'auto',
            backgroundColor: '#1f2937'
          }}
        >
          {children}
        </div>
      </div>
    </div>
  );
}